# Resistor Edu · 사각형·다각형·path

과제 ID: layout-primitives · edu-coursepack-20261014-v1 · 수준 2 · 권장 50분

이 문서는 학생용 과제 설명입니다. 학생 제출물이 아니며 실행 결과를 포함하지 않습니다.

## 목표

형상으로 확인할 사실과 모델이 필요한 판단을 구분합니다.

## 사전 지식

- 전압·전류·단위
- 현재 프로젝트와 revision 확인

## 입력 조건

- 작업 layer/purpose·net metadata·grid
- 교육용 기하·표시 적층과 실제 foundry 공정 자료를 명시적으로 구분합니다.

변경 변수: 지원 배선 폭 하나

## 수행

1. 새 과제 사본을 만들고 입력·모델·도구 준비 상태를 기록합니다.
2. 회로·포트 또는 기하 구조를 읽고 먼저 변화 방향을 예측합니다.
3. 변경 전 실제 계산/해석/관찰 증거를 저장합니다. 미지원 항목은 이유를 적습니다.
4. 지원 배선 폭 하나 이외의 조건을 유지하고 변경 후 증거와 비교합니다.
5. 관찰 → 규칙/모델 → 판단 근거 → 다음 실험 순서로 자신의 설명을 저장합니다.

## 관찰

- 작업 layer/purpose·net metadata·grid
- 직접 확인한 좌표·layer·revision·변경 전후

## 사전·사후 개념 질문

1. 화면 pixel과 저장된 mask 좌표가 같은 단위인가요?
2. 전기·공정 결론을 내리기 위해 추가로 필요한 데이터는?

같은 질문에 실험 전 예측과 실험 후 근거를 각각 직접 작성합니다. 자동 정답·점수는 없습니다.

## 제출 증거

- 조건·revision 비교표
- 실제 실행 ID/로그 또는 실행 불가 사유
- 학생이 작성한 해석과 다음 실험

## 평가 기준 · 교수자 수동 검토

- 20점 · 프로젝트·revision·모델·입력 조건을 재현 가능하게 기록
- 30점 · 작업 layer/purpose·net metadata·grid
- 30점 · 화면 pixel과 저장된 mask 좌표가 같은 단위인가요?
- 20점 · 한계·오류·다음 실험을 근거와 함께 설명

## 실행·판정 범위

기하·표시 관찰 과제. matching·성능 수치는 실제 추출/모델 없이 생성하지 않습니다.

DRC/LVS/PEX/시뮬레이션은 독립입니다. not_run·unavailable·엔진 오류·검사 불합격·현재/이전 revision을 구분합니다. 제조 승인과 교육 효과는 증명되지 않았습니다.

## 기하 참고 그림

해당 과제의 기하 fixture 없음

## 학생 레퍼런스

- [DBU와 µm](../references/dbu-grid.md)
- [대칭·centroid와 matching](../references/geometry-matching.md)
- [주변 환경·방향·dummy](../references/matching-environment.md)

