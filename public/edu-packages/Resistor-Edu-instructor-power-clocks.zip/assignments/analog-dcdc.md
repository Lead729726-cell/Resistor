# Resistor Edu · 2:1 SC DC-DC · ripple

과제 ID: analog-dcdc · edu-coursepack-20261014-v1 · 수준 3 · 권장 75분

이 문서는 교수자 과제·평가 가이드입니다. 학생 제출물이 아니며 실행 결과를 포함하지 않습니다.

## 목표

입력·모델 조건을 기록하고 다음 항목을 해석합니다: 정상 구간 출력·ripple·switch 경로.

## 사전 지식

- 전압·전류·단위
- 현재 프로젝트와 revision 확인

## 입력 조건

- Cflying=Cout=1nF, RL=50kΩ
- 공개 SKY130 모델·TT/27°C. 외부 bias/reference/driver는 testbench 가정.

변경 변수: load_Ohm: 50k → 25kΩ

## 수행

1. 새 과제 사본을 만들고 입력·모델·도구 준비 상태를 기록합니다.
2. 회로·포트 또는 기하 구조를 읽고 먼저 변화 방향을 예측합니다.
3. 변경 전 실제 계산/해석/관찰 증거를 저장합니다. 미지원 항목은 이유를 적습니다.
4. load_Ohm: 50k → 25kΩ 이외의 조건을 유지하고 변경 후 증거와 비교합니다.
5. 관찰 → 규칙/모델 → 판단 근거 → 다음 실험 순서로 자신의 설명을 저장합니다.

## 관찰

- 정상 구간 출력·ripple·switch 경로
- 바이어스·finite stimulus·회로 parameter

## 사전·사후 개념 질문

1. 이상 2:1 비와 부하가 걸린 actual output은 왜 다른가요?
2. 실제 기생·noise·mismatch 평가에 추가로 필요한 모델과 검사는?

같은 질문에 실험 전 예측과 실험 후 근거를 각각 직접 작성합니다. 자동 정답·점수는 없습니다.

## 제출 증거

- 조건·revision 비교표
- 실제 실행 ID/로그 또는 실행 불가 사유
- 학생이 작성한 해석과 다음 실험

## 평가 기준 · 교수자 수동 검토

- 20점 · 프로젝트·revision·모델·입력 조건을 재현 가능하게 기록
- 30점 · 정상 구간 출력·ripple·switch 경로
- 30점 · 이상 2:1 비와 부하가 걸린 actual output은 왜 다른가요?
- 20점 · 한계·오류·다음 실험을 근거와 함께 설명

## 실행·판정 범위

기존 실제 MOS template를 회로 사본으로 생성. full PVT/noise/MC/EMIR/ESD/manufacturing 미검증.

DRC/LVS/PEX/시뮬레이션은 독립입니다. not_run·unavailable·엔진 오류·검사 불합격·현재/이전 revision을 구분합니다. 제조 승인과 교육 효과는 증명되지 않았습니다.

## 기하 참고 그림

해당 과제의 기하 fixture 없음

## 학생 레퍼런스

- [AC 소신호 해석](../references/ac-small-signal.md)
- [headroom·swing·rail](../references/headroom.md)
- [SC DC-DC 변환비](../references/sc-dcdc.md)

## 교수자 해설

예측과 실제 증거의 차이를 토론합니다. 수치·PASS는 계산 또는 해당 실제 엔진 결과에서만 확인합니다.

토론할 오류:

- 체크리스트 완료는 엔진 검증이 아닙니다.
- 같은 소스라도 모델·도구·revision이 바뀌면 과거 결과입니다.

고정 성능 정답은 제공하지 않습니다. 실제 학생 프로젝트의 모델·revision·로그로 결과를 검토하세요.

