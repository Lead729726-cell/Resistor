# Resistor Edu · 전가산기 · SUM/COUT

과제 ID: digital-full-adder · edu-coursepack-20261014-v1 · 수준 2 · 권장 50분

이 문서는 학생용 과제 설명입니다. 학생 제출물이 아니며 실행 결과를 포함하지 않습니다.

## 목표

기존 셀의 연결과 다음 관측을 설명합니다: SUM parity와 carry · 9개 NAND 연결.

## 사전 지식

- 전압·전류·단위
- 현재 프로젝트와 revision 확인

## 입력 조건

- A/B/CIN 8개 조합·기존 NAND 계층
- 새 사본·실제 run ID·revision을 기록하며 원본 셀은 보존합니다.

변경 변수: 입력 slew 또는 output load 하나

## 수행

1. 새 과제 사본을 만들고 입력·모델·도구 준비 상태를 기록합니다.
2. 회로·포트 또는 기하 구조를 읽고 먼저 변화 방향을 예측합니다.
3. 변경 전 실제 계산/해석/관찰 증거를 저장합니다. 미지원 항목은 이유를 적습니다.
4. 입력 slew 또는 output load 하나 이외의 조건을 유지하고 변경 후 증거와 비교합니다.
5. 관찰 → 규칙/모델 → 판단 근거 → 다음 실험 순서로 자신의 설명을 저장합니다.

## 관찰

- SUM parity와 carry · 9개 NAND 연결
- 논리·timing·물리 검증을 각각 기록

## 사전·사후 개념 질문

1. 세 입력이 모두 HIGH일 때 SUM과 COUT은 왜 둘 다 HIGH인가요?
2. 새 셀 자동 설계 대신 기존 계층을 읽고 재사용하는 이점은?

같은 질문에 실험 전 예측과 실험 후 근거를 각각 직접 작성합니다. 자동 정답·점수는 없습니다.

## 제출 증거

- 조건·revision 비교표
- 실제 실행 ID/로그 또는 실행 불가 사유
- 학생이 작성한 해석과 다음 실험

## 평가 기준 · 교수자 수동 검토

- 20점 · 프로젝트·revision·모델·입력 조건을 재현 가능하게 기록
- 30점 · SUM parity와 carry · 9개 NAND 연결
- 30점 · 세 입력이 모두 HIGH일 때 SUM과 COUT은 왜 둘 다 HIGH인가요?
- 20점 · 한계·오류·다음 실험을 근거와 함께 설명

## 실행·판정 범위

실제 기존 CMOS 계층. 새 제조 표준 셀 라이브러리 인증 아님. 초기 physical_core=false.

DRC/LVS/PEX/시뮬레이션은 독립입니다. not_run·unavailable·엔진 오류·검사 불합격·현재/이전 revision을 구분합니다. 제조 승인과 교육 효과는 증명되지 않았습니다.

## 기하 참고 그림

해당 과제의 기하 fixture 없음

## 학생 레퍼런스

- [논리 진리표와 물리 경로](../references/logic-path.md)
- [계층과 포트 mapping](../references/hierarchy-ports.md)
- [표준 셀 라이브러리와 P&R](../references/pnr-library.md)

