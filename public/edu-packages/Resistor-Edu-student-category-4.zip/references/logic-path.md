# 논리 진리표와 물리 경로

Resistor Edu · logic-path

기존 셀의 연결과 입력에 따른 conducting path를 읽습니다.

단위: V, s

조건: 각 입력 조합과 안정 구간·threshold 명시

주의할 해석: 진리표 검사 통과는 모든 timing arc/Liberty characterization이 아닙니다.

다음 실험: NAND와 NOR의 최악 경로 후보를 표시하세요.

[기존 물리 셀·칩 레퍼런스 · 독립 검사 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/physical-library/README.md) · MIT · 역사적 보고서이며 현재 PASS로 표시하지 않음
