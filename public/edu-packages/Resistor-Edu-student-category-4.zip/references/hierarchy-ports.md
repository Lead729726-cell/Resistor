# 계층과 포트 mapping

Resistor Edu · hierarchy-ports

하위 셀의 정의와 상위 instance 연결을 나눕니다.

단위: net names, integer DBU

조건: 포트 순서·namespace·대상 revision

주의할 해석: schematic 연결과 블록 사이 실제 mask 배선은 별도입니다.

다음 실험: 복사 preview에서 추가 도형과 port mapping을 확인하세요.

[기존 물리 셀·칩 레퍼런스 · 독립 검사 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/physical-library/README.md) · MIT · 역사적 보고서이며 현재 PASS로 표시하지 않음
