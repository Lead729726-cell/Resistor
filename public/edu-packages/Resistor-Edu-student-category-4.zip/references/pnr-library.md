# 표준 셀 라이브러리와 P&R

Resistor Edu · pnr-library

셀 특성과 전체 칩 배치·배선·timing 최적화의 역할을 구분합니다.

단위: LEF/Liberty/netlist/GDS

조건: 표준 셀·공정 룰·constraints·timing 데이터 필요

주의할 해석: P&R을 배선만 하는 과정으로 설명하지 않습니다.

다음 실험: Liberty와 GDS가 각각 담는 데이터를 대조하세요.

[OpenROAD · RTL에서 물리 구현까지](https://github.com/The-OpenROAD-Project/OpenROAD/blob/master/README.md) · 외부 링크만 포함 · OpenROAD는 이 과제의 기본 실행 엔진이 아님
