# 디지털·계층

Resistor Edu · 학생 패키지 · edu-coursepack-20261014-v1

8개 과제와 3개 레퍼런스. MIT로 작성된 원본 교육 자료이며 원본 외부 문서/PDK/도구 라이선스는 별도입니다.

## 시작

1. 앱에서 **다른 과정 → 과제·레퍼런스**를 열거나 이 폴더의 catalog.json과 과제 문서를 읽습니다.
2. 각 과제의 지원 모델·입력·미지원 범위를 읽고 새 프로젝트 사본을 시작합니다.
3. 실제 결과 ID·revision과 자신의 설명을 저장합니다.
4. 제출은 templates/student-submission.json 또는 앱에서 내보낸 학생 기록을 사용합니다.

standalone SPICE: ngspice -b fixtures/<id>.cir. 이 deck들은 이상 선형 회로만 포함합니다. 실행할 도구가 없으면 unavailable이며 샘플 결과로 대체하지 않습니다.

실습 체크·계산·형상 생성은 DRC/LVS/PEX PASS가 아닙니다. 기록된 시간은 경과 시간이며 실제 학습 집중 시간을 측정하지 않습니다. 설명 정확도·완료율·교육 효과는 교수자/사용자 평가가 필요합니다.

## 과제

- [NAND2 · 직렬 NMOS 경로](assignments/digital-nand.md) · 디지털·계층 · L2
- [NOR2 · 병렬 NMOS 경로](assignments/digital-nor.md) · 디지털·계층 · L2
- [XOR2 · 연결을 따라 parity 읽기](assignments/digital-xor.md) · 디지털·계층 · L2
- [MUX2 · 선택과 전달 경로](assignments/digital-mux2.md) · 디지털·계층 · L2
- [MUX4 · 선택 안정 시간](assignments/digital-mux4.md) · 디지털·계층 · L2
- [전가산기 · SUM/COUT](assignments/digital-full-adder.md) · 디지털·계층 · L2
- [4bit ripple carry · 지연 경로](assignments/digital-adder4.md) · 디지털·계층 · L2
- [표준 셀·P&R·timing 경계](assignments/digital-pnr.md) · 디지털·계층 · L2
