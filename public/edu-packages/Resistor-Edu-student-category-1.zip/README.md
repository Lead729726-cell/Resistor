# 기초 계산

Resistor Edu · 학생 패키지 · edu-coursepack-20261014-v1

18개 과제와 3개 레퍼런스. MIT로 작성된 원본 교육 자료이며 원본 외부 문서/PDK/도구 라이선스는 별도입니다.

## 시작

1. 앱에서 **다른 과정 → 과제·레퍼런스**를 열거나 이 폴더의 catalog.json과 과제 문서를 읽습니다.
2. 각 과제의 지원 모델·입력·미지원 범위를 읽고 새 프로젝트 사본을 시작합니다.
3. 실제 결과 ID·revision과 자신의 설명을 저장합니다.
4. 제출은 templates/student-submission.json 또는 앱에서 내보낸 학생 기록을 사용합니다.

standalone SPICE: ngspice -b fixtures/<id>.cir. 이 deck들은 이상 선형 회로만 포함합니다. 실행할 도구가 없으면 unavailable이며 샘플 결과로 대체하지 않습니다.

실습 체크·계산·형상 생성은 DRC/LVS/PEX PASS가 아닙니다. 기록된 시간은 경과 시간이며 실제 학습 집중 시간을 측정하지 않습니다. 설명 정확도·완료율·교육 효과는 교수자/사용자 평가가 필요합니다.

## 과제

- [색띠와 허용오차](assignments/calc-resistor-color-code.md) · 기초 계산 · L1
- [E-series와 목표 오차](assignments/calc-resistor-series.md) · 기초 계산 · L1
- [병렬 저항과 branch 전류](assignments/calc-parallel-resistor.md) · 기초 계산 · L1
- [직렬 저항과 전압 분담](assignments/calc-series-resistor.md) · 기초 계산 · L1
- [분압비와 전류 비용](assignments/calc-voltage-divider.md) · 기초 계산 · L1
- [LED 전류 제한과 정격](assignments/calc-led-resistor.md) · 기초 계산 · L1
- [저항 손실과 전압 제곱](assignments/calc-power-dissipation.md) · 기초 계산 · L1
- [옴의 법칙과 단위](assignments/calc-ohms-law.md) · 기초 계산 · L1
- [RC settling과 대역폭](assignments/calc-rc-time-constant.md) · 기초 계산 · L1
- [RL 전류 응답](assignments/calc-rl-time-constant.md) · 기초 계산 · L1
- [RLC 공진과 Q](assignments/calc-rlc-resonance.md) · 기초 계산 · L1
- [커패시터 전하와 에너지](assignments/calc-capacitor-calculator.md) · 기초 계산 · L1
- [ADC 코드 수와 정의](assignments/calc-adc-resolution.md) · 기초 계산 · L1
- [DAC endpoint와 step](assignments/calc-dac-resolution.md) · 기초 계산 · L1
- [이상적 폐루프 이득](assignments/calc-op-amp-gain.md) · 기초 계산 · L1
- [전압비·전력비 dB](assignments/calc-db-conversion.md) · 기초 계산 · L1
- [주파수·주기·각주파수](assignments/calc-frequency-period.md) · 기초 계산 · L1
- [SI prefix 오류 찾기](assignments/calc-unit-converter.md) · 기초 계산 · L1
