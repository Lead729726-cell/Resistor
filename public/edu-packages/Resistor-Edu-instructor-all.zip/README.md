# Resistor Edu 전체 과제·레퍼런스

Resistor Edu · 교수자 패키지 · edu-coursepack-20261014-v1

72개 과제와 40개 레퍼런스. MIT로 작성된 원본 교육 자료이며 원본 외부 문서/PDK/도구 라이선스는 별도입니다.

## 시작

1. 앱에서 **다른 과정 → 과제·레퍼런스**를 열거나 이 폴더의 catalog.json과 과제 문서를 읽습니다.
2. 각 과제의 지원 모델·입력·미지원 범위를 읽고 새 프로젝트 사본을 시작합니다.
3. 실제 결과 ID·revision과 자신의 설명을 저장합니다.
4. 제출은 templates/student-submission.json 또는 앱에서 내보낸 학생 기록을 사용합니다.

standalone SPICE: ngspice -b fixtures/<id>.cir. 이 deck들은 이상 선형 회로만 포함합니다. 실행할 도구가 없으면 unavailable이며 샘플 결과로 대체하지 않습니다.

실습 체크·계산·형상 생성은 DRC/LVS/PEX PASS가 아닙니다. 기록된 시간은 경과 시간이며 실제 학습 집중 시간을 측정하지 않습니다. 설명 정확도·완료율·교육 효과는 교수자/사용자 평가가 필요합니다.

## 과제

- [색띠와 허용오차](assignments/calc-resistor-color-code.md) · 기초 계산 · L1
- [E-series와 목표 오차](assignments/calc-resistor-series.md) · 기초 계산 · L1
- [병렬 저항과 branch 전류](assignments/calc-parallel-resistor.md) · 기초 계산 · L1
- [직렬 저항과 전압 분담](assignments/calc-series-resistor.md) · 기초 계산 · L1
- [분압비와 전류 비용](assignments/calc-voltage-divider.md) · 기초 계산 · L1
- [LED 전류 제한과 정격](assignments/calc-led-resistor.md) · 기초 계산 · L1
- [저항 손실과 전압 제곱](assignments/calc-power-dissipation.md) · 기초 계산 · L1
- [옴의 법칙과 단위](assignments/calc-ohms-law.md) · 기초 계산 · L1
- [RC settling과 대역폭](assignments/calc-rc-time-constant.md) · 기초 계산 · L1
- [RL 전류 응답](assignments/calc-rl-time-constant.md) · 기초 계산 · L1
- [RLC 공진과 Q](assignments/calc-rlc-resonance.md) · 기초 계산 · L1
- [커패시터 전하와 에너지](assignments/calc-capacitor-calculator.md) · 기초 계산 · L1
- [ADC 코드 수와 정의](assignments/calc-adc-resolution.md) · 기초 계산 · L1
- [DAC endpoint와 step](assignments/calc-dac-resolution.md) · 기초 계산 · L1
- [이상적 폐루프 이득](assignments/calc-op-amp-gain.md) · 기초 계산 · L1
- [전압비·전력비 dB](assignments/calc-db-conversion.md) · 기초 계산 · L1
- [주파수·주기·각주파수](assignments/calc-frequency-period.md) · 기초 계산 · L1
- [SI prefix 오류 찾기](assignments/calc-unit-converter.md) · 기초 계산 · L1
- [1.8V 전압 분배기 · OP와 전류](assignments/circuit-divider.md) · 기초 회로 · L1
- [분배기에 부하를 연결하면](assignments/circuit-loaded-divider.md) · 기초 회로 · L1
- [병렬 branch의 KCL](assignments/circuit-parallel.md) · 기초 회로 · L1
- [직렬 경로의 KVL](assignments/circuit-series.md) · 기초 회로 · L1
- [RC step · τ와 63.2%](assignments/circuit-rc-charge.md) · 기초 회로 · L2
- [RC 방전 · 초기조건을 명시하기](assignments/circuit-rc-discharge.md) · 기초 회로 · L2
- [RC AC · −3dB와 위상](assignments/circuit-rc-ac.md) · 기초 회로 · L2
- [테브난 출력 저항과 부하](assignments/circuit-thevenin.md) · 기초 회로 · L2
- [NMOS I–V · W/L과 동작 영역](assignments/mos-iv.md) · MOS·바이어스 · L2
- [공통 소스 · OP headroom](assignments/mos-common-source.md) · MOS·바이어스 · L2
- [게이트 분압·커플링 C](assignments/mos-bias-divider.md) · MOS·바이어스 · L2
- [전류 미러 · compliance](assignments/mos-current-mirror.md) · MOS·바이어스 · L2
- [차동 쌍 · differential와 common mode](assignments/mos-differential-pair.md) · MOS·바이어스 · L2
- [캐스코드 · 출력 저항과 headroom](assignments/mos-cascode.md) · MOS·바이어스 · L3
- [연결형 CMOS · 부하와 지연](assignments/mos-inverter-load.md) · MOS·바이어스 · L2
- [NAND2 · 직렬 NMOS 경로](assignments/digital-nand.md) · 디지털·계층 · L2
- [NOR2 · 병렬 NMOS 경로](assignments/digital-nor.md) · 디지털·계층 · L2
- [XOR2 · 연결을 따라 parity 읽기](assignments/digital-xor.md) · 디지털·계층 · L2
- [MUX2 · 선택과 전달 경로](assignments/digital-mux2.md) · 디지털·계층 · L2
- [MUX4 · 선택 안정 시간](assignments/digital-mux4.md) · 디지털·계층 · L2
- [전가산기 · SUM/COUT](assignments/digital-full-adder.md) · 디지털·계층 · L2
- [4bit ripple carry · 지연 경로](assignments/digital-adder4.md) · 디지털·계층 · L2
- [표준 셀·P&R·timing 경계](assignments/digital-pnr.md) · 디지털·계층 · L2
- [5MOS OTA · DC와 AC](assignments/analog-ota.md) · 아날로그·전원 · L3
- [Miller OTA · 보상과 Rz](assignments/analog-miller.md) · 아날로그·전원 · L3
- [PGA · 폐루프 gain와 swing](assignments/analog-pga.md) · 아날로그·전원 · L3
- [2차 필터 · pole와 bandwidth](assignments/analog-filter.md) · 아날로그·전원 · L3
- [TIA · 전류를 전압으로](assignments/analog-tia.md) · 아날로그·전원 · L3
- [비교기 · 작은 입력과 지연](assignments/analog-comparator.md) · 아날로그·전원 · L3
- [LDO · 부하 step과 dropout](assignments/analog-ldo.md) · 아날로그·전원 · L3
- [2:1 SC DC-DC · ripple](assignments/analog-dcdc.md) · 아날로그·전원 · L3
- [ΣΔ 적분기 · 되먹임의 상태](assignments/adc-sdm-integrator.md) · 데이터 변환 · L3
- [ΣΔ modulator · bit 밀도](assignments/adc-sdm-density.md) · 데이터 변환 · L3
- [CIC2×256 · decimation](assignments/adc-sdm-cic.md) · 데이터 변환 · L3
- [ΣΔ FFT · coherent 조건](assignments/adc-sdm-spectrum.md) · 데이터 변환 · L3
- [SAR · 샘플 스위치](assignments/adc-sar-switch.md) · 데이터 변환 · L3
- [SAR · binary CDAC와 dummy](assignments/adc-sar-cdac.md) · 데이터 변환 · L3
- [SAR · 8회 bit trial](assignments/adc-sar-core.md) · 데이터 변환 · L3
- [정수 DBU·grid·단위](assignments/layout-dbu.md) · 레이아웃·공정 · L2
- [사각형·다각형·path](assignments/layout-primitives.md) · 레이아웃·공정 · L2
- [복사·회전·미러·Undo](assignments/layout-transform.md) · 레이아웃·공정 · L2
- [대칭 배치·간격의 근거](assignments/layout-symmetry.md) · 레이아웃·공정 · L2
- [ABBA·common centroid](assignments/layout-centroid.md) · 레이아웃·공정 · L2
- [dummy와 경계 환경](assignments/layout-dummy.md) · 레이아웃·공정 · L2
- [배선 길이와 RC 증거](assignments/layout-interconnect.md) · 레이아웃·공정 · L2
- [chip envelope·aspect ratio](assignments/layout-chip-area.md) · 레이아웃·공정 · L2
- [layer mapping과 2.5D 단면](assignments/layout-stack.md) · 레이아웃·공정 · L2
- [hole·step·coverage의 가설](assignments/layout-topography.md) · 레이아웃·공정 · L2
- [DRC · 폭/간격 오류 읽기](assignments/verify-drc.md) · 검증·재현 · L2
- [LVS · net/소자/핀 일치](assignments/verify-lvs.md) · 검증·재현 · L2
- [PEX · RC와 post 해석](assignments/verify-pex.md) · 검증·재현 · L2
- [PVT · 같은 회로, 다른 모델](assignments/verify-pvt.md) · 검증·재현 · L2
- [revision·모델 변경과 과거 결과](assignments/verify-revision.md) · 검증·재현 · L2
- [미설치·검사 불합격·엔진 오류](assignments/verify-unavailable.md) · 검증·재현 · L2
