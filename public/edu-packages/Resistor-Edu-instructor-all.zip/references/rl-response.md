# RL 전류와 저장 에너지

Resistor Edu · rl-response

직렬 RL 전류가 연속적으로 변합니다.

수식: τ=L/R; E=½LI²

단위: s, H, Ω, J

조건: 선형 L, 포화·기생 제외

주의할 해석: 실제 coil의 DC 저항·포화·자기 손실은 추가 모델입니다.

다음 실험: R을 두 배로 바꾼 τ를 계산하세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드
