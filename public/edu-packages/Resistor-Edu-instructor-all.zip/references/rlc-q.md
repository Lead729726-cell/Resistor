# 직렬 RLC 공진과 Q

Resistor Edu · rlc-q

손실과 공진 주파수의 역할을 나눕니다.

수식: f0=1/(2π√LC); Q=√(L/C)/R

단위: Hz, H, F, Ω

조건: 직렬 RLC·이상 L/C

주의할 해석: 병렬 RLC의 Q 식을 그대로 섞지 않습니다.

다음 실험: R만 바꾸고 f0와 Q의 변화를 설명하세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드
