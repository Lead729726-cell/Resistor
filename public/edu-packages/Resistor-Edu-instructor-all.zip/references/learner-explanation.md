# 학생 설명과 교수자 평가

Resistor Edu · learner-explanation

자신의 관찰·근거·다음 실험을 직접 작성합니다.

조건: 원본 학생 입력과 교수자 가이드 분리

주의할 해석: 자동 해설·QA fixture를 학생 제출·학습 효과 증명으로 저장하지 않습니다.

다음 실험: 사전/사후 설명을 보존하고 교수자에게 검토를 요청하세요.

[연결형 CMOS 실습과 실제 모델 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/edu-inverter-lab.md) · MIT · 실행 증거는 해당 revision에만 유효
