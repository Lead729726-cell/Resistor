# 대칭·centroid와 matching

Resistor Edu · geometry-matching

좌표 특성과 전기적 mismatch를 별도 증거로 취급합니다.

수식: centroid=(ΣAi xi/ΣAi, ΣAi yi/ΣAi)

단위: µm, µm²

조건: 같은 unit 면적·기하 확인. gradient 선형 가정은 명시.

주의할 해석: 같은 centroid는 orientation·이웃·배선·고차 gradient 일치를 보장하지 않습니다.

다음 실험: ABBA와 ABAB의 좌표·이웃 차이를 적으세요.

[ALIGN · 대칭·배치·경계 제약](https://align-analoglayout.github.io/ALIGN-public/notes/const.html) · 외부 링크만 포함 · 독립 ALIGN 엔진 실행 아님
