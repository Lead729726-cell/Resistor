# step·hole·coverage와 해상도

Resistor Edu · topography-resolution

가정 기반 heightmap의 해상도와 미해결 얇은 film을 밝힙니다.

단위: µm, voxel size

조건: 입력 recipe·측정 데이터·재료/공정 모델의 유무

주의할 해석: 그림만으로 calibrated TCAD·결함·foundry 공정 성능을 확정하지 않습니다.

다음 실험: 격자보다 얇은 막을 unresolved로 분류하세요.

[KLayout XSection 프로젝트](https://klayoutmatthias.github.io/xsection/) · 외부 링크만 포함 · 현재 Edu에 XSection 실행 연동을 주장하지 않음

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인
