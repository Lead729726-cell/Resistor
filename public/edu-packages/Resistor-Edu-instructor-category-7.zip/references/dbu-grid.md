# DBU와 µm

Resistor Edu · dbu-grid

도형은 정수 좌표, 물리 길이는 DBU 배율로 표현합니다.

수식: length_um=length_DBU×dbu_um

단위: DBU, µm

조건: 현재 layout DBU 사용

주의할 해석: 교육용 예시 DBU=0.001µm를 모든 GDS에 강제하지 않습니다.

다음 실험: export/reimport 좌표와 DBU를 비교하세요.

[KLayout 공식 2.5D 표현](https://www.klayout.de/doc/about/25d_view.html) · 외부 링크만 포함
