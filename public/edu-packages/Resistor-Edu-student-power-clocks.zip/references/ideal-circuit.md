# 이상 모델의 적용 범위

Resistor Edu · ideal-circuit

정확한 식도 적용 모델을 벗어나면 예측을 보장하지 않습니다.

수식: V=IR; Q=CV

단위: V, A, Ω, C, F

조건: 선형·고정 R/C; 열·비선형 제외

주의할 해석: 이상 부품 계산을 실제 PDK 성능으로 쓰지 않습니다.

다음 실험: 모델 없이 알 수 없는 현상을 목록으로 적으세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드
