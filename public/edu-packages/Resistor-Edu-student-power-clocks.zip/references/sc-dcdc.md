# SC DC-DC 변환비

Resistor Edu · sc-dcdc

이상 charge transfer와 switch·부하 손실을 구분합니다.

단위: V, A, F, Hz

조건: 클록·switch·C·load 모델 명시

주의할 해석: 2:1 ideal ratio를 actual regulation 보증으로 쓰지 않습니다.

다음 실험: steady interval ripple과 공급 전류를 보세요.

[기존 물리 셀·칩 레퍼런스 · 독립 검사 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/physical-library/README.md) · MIT · 역사적 보고서이며 현재 PASS로 표시하지 않음
