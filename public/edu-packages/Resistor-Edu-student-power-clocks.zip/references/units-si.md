# SI 단위와 prefix

Resistor Edu · units-si

입력의 물리량과 prefix를 먼저 읽습니다.

수식: x_SI = x × prefix_scale

단위: m=10⁻³, µ=10⁻⁶, n=10⁻⁹, p=10⁻¹², f=10⁻¹⁵

조건: 같은 물리량 사이의 변환

주의할 해석: SPICE의 m과 meg를 혼동하지 않습니다.

다음 실험: 1nF와 1000pF 입력이 같은 결과인지 비교하세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
