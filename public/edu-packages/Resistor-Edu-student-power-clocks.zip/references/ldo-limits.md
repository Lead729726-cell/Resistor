# LDO load transient 한계

Resistor Edu · ldo-limits

출력 C·ESR·부하·dropout 조건을 명시합니다.

단위: V, A, F, s

조건: 실제 loop·external reference/bias·testbench

주의할 해석: 한 step 통과가 full PVT·안정성·열 인증은 아닙니다.

다음 실험: 부하와 C 중 하나만 바꿔 actual undershoot를 보세요.

[기존 물리 셀·칩 레퍼런스 · 독립 검사 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/physical-library/README.md) · MIT · 역사적 보고서이며 현재 PASS로 표시하지 않음
