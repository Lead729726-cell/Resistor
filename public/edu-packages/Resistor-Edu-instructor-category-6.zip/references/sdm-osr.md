# ΣΔ bitstream과 OSR

Resistor Edu · sdm-osr

modulator와 decimator의 역할을 구분합니다.

단위: Hz, samples, code

조건: 현재 reference의 modulator clock·CIC2×256·settling 명시

주의할 해석: OSR만으로 ENOB·noise-shaping 성능을 확정하지 않습니다.

다음 실험: 같은 입력에서 BITSTREAM과 CODE/VALID를 연결하세요.

[Sigma-delta8 · 계층·CIC·실행 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/sigma-delta8/README.md) · MIT · CODE 비트 수와 ENOB를 구분
