# sampling과 alias

Resistor Edu · sampling-alias

샘플 속도·입력 대역과 anti-alias 필요성을 구분합니다.

단위: Hz

조건: bandlimit와 실제 sample/valid rate 확인

주의할 해석: 출력 코드 폭이 alias 방지를 보장하지 않습니다.

다음 실험: filter 전후 signal path를 표시하세요.

[Sigma-delta8 · 계층·CIC·실행 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/sigma-delta8/README.md) · MIT · CODE 비트 수와 ENOB를 구분

[SAR8 · 모델·외부 제어·면적 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/sar-adc.md) · MIT · 전체 controller mask/timing 미지원
