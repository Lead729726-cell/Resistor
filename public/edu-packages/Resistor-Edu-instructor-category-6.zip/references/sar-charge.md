# SAR charge redistribution

Resistor Edu · sar-charge

샘플 전하와 trial 전압을 추적합니다.

수식: VTOP=VCM−VIN+VREF·trial/256

단위: V

조건: 이상 equal units·8bit·명시 driver/reference. actual MOS는 별도.

주의할 해석: 이상식이 comparator noise/offset·switch injection을 없애지 않습니다.

다음 실험: 실제 COMP decision 로그와 trial을 나란히 보세요.

[SAR8 · 모델·외부 제어·면적 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/sar-adc.md) · MIT · 전체 controller mask/timing 미지원

[Analog Devices · SAR 구조와 charge redistribution](https://www.analog.com/en/resources/technical-articles/successive-approximation-registers-sar-and-flash-adcs.html) · 외부 링크만 포함
