# FFT 관측 조건

Resistor Edu · fft-coherent

입력 주파수·sample 수·window·settling을 함께 기록합니다.

수식: fin=k·fs/N

단위: Hz, samples

조건: 정수 k·기록된 actual valid frames

주의할 해석: DC offset·settling frame·leakage를 성능으로 오해하지 않습니다.

다음 실험: 입력 주파수와 window를 기록하고 spectrum을 확인하세요.

[Sigma-delta8 · 계층·CIC·실행 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/examples/sigma-delta8/README.md) · MIT · CODE 비트 수와 ENOB를 구분
