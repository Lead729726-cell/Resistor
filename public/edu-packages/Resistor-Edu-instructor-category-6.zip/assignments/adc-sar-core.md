# Resistor Edu · SAR · 8회 bit trial

과제 ID: adc-sar-core · edu-coursepack-20261014-v1 · 수준 3 · 권장 90분

이 문서는 교수자 과제·평가 가이드입니다. 학생 제출물이 아니며 실행 결과를 포함하지 않습니다.

## 목표

필요한 하위 블록과 실제 관측 신호를 연결합니다.

## 사전 지식

- 전압·전류·단위
- 현재 프로젝트와 revision 확인

## 입력 조건

- VIN=0.6V, VREF=1.2V, acquisition=bit period=2µs
- 블록별 입력/외부 driver·reference·모델과 지원 해석을 먼저 확인합니다.

변경 변수: input_V: 0.6 → 0.3V

## 수행

1. 새 과제 사본을 만들고 입력·모델·도구 준비 상태를 기록합니다.
2. 회로·포트 또는 기하 구조를 읽고 먼저 변화 방향을 예측합니다.
3. 변경 전 실제 계산/해석/관찰 증거를 저장합니다. 미지원 항목은 이유를 적습니다.
4. input_V: 0.6 → 0.3V 이외의 조건을 유지하고 변경 후 증거와 비교합니다.
5. 관찰 → 규칙/모델 → 판단 근거 → 다음 실험 순서로 자신의 설명을 저장합니다.

## 관찰

- SAMPLE·TOP·COMP·trial 또는 CODE/VALID
- digital replay와 transistor timing·물리 controller를 구분

## 사전·사후 개념 질문

1. 실제 comparator decision과 이상 code 공식의 차이는?
2. 이번 결과에서 ENOB/INL/DNL/noise 중 실제로 측정한 항목은?

같은 질문에 실험 전 예측과 실험 후 근거를 각각 직접 작성합니다. 자동 정답·점수는 없습니다.

## 제출 증거

- 조건·revision 비교표
- 실제 실행 ID/로그 또는 실행 불가 사유
- 학생이 작성한 해석과 다음 실험

## 평가 기준 · 교수자 수동 검토

- 20점 · 프로젝트·revision·모델·입력 조건을 재현 가능하게 기록
- 30점 · SAMPLE·TOP·COMP·trial 또는 CODE/VALID
- 30점 · 실제 comparator decision과 이상 code 공식의 차이는?
- 20점 · 한계·오류·다음 실험을 근거와 함께 설명

## 실행·판정 범위

제한된 기존 MOS/RTL block. 고정 standalone 블록은 parameter 없는 경우 읽기/기존 testbench 관찰. 전체 SoC·8bit ENOB·controller mask/timing 인증 없음.

DRC/LVS/PEX/시뮬레이션은 독립입니다. not_run·unavailable·엔진 오류·검사 불합격·현재/이전 revision을 구분합니다. 제조 승인과 교육 효과는 증명되지 않았습니다.

## 기하 참고 그림

해당 과제의 기하 fixture 없음

## 학생 레퍼런스

- [ADC bin과 endpoint](../references/adc-code-definitions.md)
- [SAR charge redistribution](../references/sar-charge.md)
- [FFT 관측 조건](../references/fft-coherent.md)
- [sampling과 alias](../references/sampling-alias.md)

## 교수자 해설

예측과 실제 증거의 차이를 토론합니다. 수치·PASS는 계산 또는 해당 실제 엔진 결과에서만 확인합니다.

토론할 오류:

- 체크리스트 완료는 엔진 검증이 아닙니다.
- 같은 소스라도 모델·도구·revision이 바뀌면 과거 결과입니다.

고정 성능 정답은 제공하지 않습니다. 실제 학생 프로젝트의 모델·revision·로그로 결과를 검토하세요.

