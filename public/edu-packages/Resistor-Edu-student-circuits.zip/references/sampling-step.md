# time step과 수치 수렴

Resistor Edu · sampling-step

실제 sample 간격·보간·solver 조건을 기록합니다.

단위: s, V, A

조건: 동일 회로·입력·모델에서 step 비교

주의할 해석: 최대 time step보다 짧은 pulse를 항상 정확히 측정할 수 있다고 가정하지 않습니다.

다음 실험: step을 절반으로 줄여 transition 수치의 안정성을 비교하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
