# 전류원·전압원 branch 부호

Resistor Edu · current-sign

음수 전류도 실제 기준 방향에 대한 유효한 결과입니다.

단위: A

조건: SPICE 전압원 전류 기준: +단자 안으로 흐름

주의할 해석: 공급 전류를 절댓값으로 바꿔 방향 정보를 지우지 않습니다.

다음 실험: 원본 signed 전류와 전원 공급 전력을 함께 적으세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
