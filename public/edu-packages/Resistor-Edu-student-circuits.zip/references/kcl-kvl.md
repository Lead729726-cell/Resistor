# KCL·KVL과 노드

Resistor Edu · kcl-kvl

전류의 기준 방향과 폐회로 전압 부호를 정합니다.

수식: Σ I_node=0; Σ ΔV_loop=0

단위: A, V

조건: 같은 노드와 폐회로·일관된 부호

주의할 해석: 단순 선 교차는 연결된 노드가 아닙니다.

다음 실험: branch 전류 합과 공급 전류를 비교하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
