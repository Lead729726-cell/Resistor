# dB·전압비·전력비

Resistor Edu · db-impedance

전압비와 전력비를 같은 식으로 취급하지 않습니다.

수식: 20log10|Av|; 10log10(Pout/Pin)

단위: dB

조건: Av²의 power 대응에는 같은 임피던스 조건

주의할 해석: 음수 dB는 음수 전압이 아니라 비가 1 미만이라는 뜻입니다.

다음 실험: 0.5배와 2배 전압 gain을 계산하세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드
