# RC charging·settling

Resistor Edu · rc-settling

한 τ와 충분한 settling 시간을 구분합니다.

수식: τ=RC; V(t)=Vf+(Vi−Vf)e^(−t/τ)

단위: s, Ω, F, V

조건: 단일 pole·일정 최종값·step 기준 시간

주의할 해석: 5τ는 약 0.674% 잔차이며 정확히 0%가 아닙니다.

다음 실험: τ·3τ·5τ의 실제 잔차를 비교하세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
