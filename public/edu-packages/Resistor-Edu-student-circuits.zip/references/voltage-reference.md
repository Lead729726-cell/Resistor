# 노드 전압과 전압강하

Resistor Edu · voltage-reference

노드 전위와 소자 양단 차이는 구분합니다.

수식: ΔV_ab=V(a)−V(b)

단위: V

조건: 기준 ground와 순서 명시

주의할 해석: V(a)를 곧바로 소자 drop이라고 부르지 않습니다.

다음 실험: ground 위치를 읽고 저항 양단 차이를 계산하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
