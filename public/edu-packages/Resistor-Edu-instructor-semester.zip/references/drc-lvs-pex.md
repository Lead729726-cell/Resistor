# DRC·LVS·PEX 독립성

Resistor Edu · drc-lvs-pex

룰 검사, 연결 비교, RC 추출은 각각 다른 질문입니다.

단위: violation count, device/net, Ω/F

조건: 실제 deck·모델·도구·입력 revision

주의할 해석: 한 job 성공으로 전체 검증 PASS를 표시하지 않습니다.

다음 실험: 각 단계의 run ID와 실패 원인을 기록하세요.

[실제 실행된 공통 물리 도구 QA · 역사적 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/physical-tools.md) · MIT · 프로젝트·revision·도구 조건이 다른 현재 결과로 재사용 금지

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인
