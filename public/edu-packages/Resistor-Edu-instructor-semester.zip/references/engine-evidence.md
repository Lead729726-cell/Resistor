# 실행·판정·미지원 상태

Resistor Edu · engine-evidence

설치 진단과 설계 실행 결과를 분리합니다.

단위: execution_status, analysis_result

조건: not_run/unavailable/queued/running/completed/failed/canceled

주의할 해석: completed/fail은 실제 검사 불합격이며 엔진 crash와 다릅니다.

다음 실험: 물리 검사 없는 계산 과제를 not_run으로 남기세요.

[실제 실행된 공통 물리 도구 QA · 역사적 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/physical-tools.md) · MIT · 프로젝트·revision·도구 조건이 다른 현재 결과로 재사용 금지
