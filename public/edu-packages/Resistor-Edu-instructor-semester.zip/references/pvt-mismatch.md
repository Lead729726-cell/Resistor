# corner·MC·mismatch 구분

Resistor Edu · pvt-mismatch

deterministic corner와 확률적 mismatch 수율은 다릅니다.

단위: °C, V, model corner, seed

조건: 각 corner와 MC 제공 모델의 실제 범위

주의할 해석: TT/SS/FF 세 점이 통계 수율이나 모든 온도 범위를 보장하지 않습니다.

다음 실험: 실행한 조건과 미실행 noise/MC 항목을 나누세요.

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인

[소규모 아날로그 SoC 레퍼런스](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/analog-soc.md) · MIT · 제조 signoff·잡음·mismatch 수율 인증 없음
