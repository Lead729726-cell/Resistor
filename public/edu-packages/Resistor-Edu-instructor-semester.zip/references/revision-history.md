# 현재 결과와 역사적 결과

Resistor Edu · revision-history

run의 revision과 입력 signature를 현재 상태와 대조합니다.

단위: project_id, revision, engine/model/deck hash

조건: 현재 dependency와 실제 provenance

주의할 해석: 같은 project 이름을 현재 검증 증거로 쓰지 않습니다.

다음 실험: 입력 한 개 수정 뒤 과거 결과 label을 확인하세요.

[연결형 CMOS 실습과 실제 모델 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/edu-inverter-lab.md) · MIT · 실행 증거는 해당 revision에만 유효

[실제 실행된 공통 물리 도구 QA · 역사적 기록](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/physical-tools.md) · MIT · 프로젝트·revision·도구 조건이 다른 현재 결과로 재사용 금지
