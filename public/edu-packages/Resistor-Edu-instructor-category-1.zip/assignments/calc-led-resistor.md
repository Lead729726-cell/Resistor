# Resistor Edu · LED 전류 제한과 정격

과제 ID: calc-led-resistor · edu-coursepack-20261014-v1 · 수준 1 · 권장 20분

이 문서는 교수자 과제·평가 가이드입니다. 학생 제출물이 아니며 실행 결과를 포함하지 않습니다.

## 목표

Vs=5V, Vf=2V, 목표 10mA에서 20mA로 비교합니다.

## 사전 지식

- 전압·전류·단위
- 현재 프로젝트와 revision 확인

## 입력 조건

- R = (Vs - Vf) / If
- 입력 label의 SI 단위·정의와 invalid input을 먼저 확인합니다.

변경 변수: 계산 입력 한 개

## 수행

1. 새 과제 사본을 만들고 입력·모델·도구 준비 상태를 기록합니다.
2. 회로·포트 또는 기하 구조를 읽고 먼저 변화 방향을 예측합니다.
3. 변경 전 실제 계산/해석/관찰 증거를 저장합니다. 미지원 항목은 이유를 적습니다.
4. 계산 입력 한 개 이외의 조건을 유지하고 변경 후 증거와 비교합니다.
5. 관찰 → 규칙/모델 → 판단 근거 → 다음 실험 순서로 자신의 설명을 저장합니다.

## 관찰

- 공식·단위·주 결과·보조 결과
- 정상 입력과 0/음수/빈 값 처리

## 사전·사후 개념 질문

1. LED Vf 온도 변화와 저항 정격 여유를 어떻게 확인할까요?
2. 계산기의 적용 조건 밖에서 추가로 필요한 데이터는 무엇인가요?

같은 질문에 실험 전 예측과 실험 후 근거를 각각 직접 작성합니다. 자동 정답·점수는 없습니다.

## 제출 증거

- 조건·revision 비교표
- 실제 실행 ID/로그 또는 실행 불가 사유
- 학생이 작성한 해석과 다음 실험

## 평가 기준 · 교수자 수동 검토

- 20점 · 프로젝트·revision·모델·입력 조건을 재현 가능하게 기록
- 30점 · 공식·단위·주 결과·보조 결과
- 30점 · LED Vf 온도 변화와 저항 정격 여유를 어떻게 확인할까요?
- 20점 · 한계·오류·다음 실험을 근거와 함께 설명

## 실행·판정 범위

고정 Vf 근사이며 LED 모델·열 해석은 아닙니다.

DRC/LVS/PEX/시뮬레이션은 독립입니다. not_run·unavailable·엔진 오류·검사 불합격·현재/이전 revision을 구분합니다. 제조 승인과 교육 효과는 증명되지 않았습니다.

## 기하 참고 그림

해당 과제의 기하 fixture 없음

## 학생 레퍼런스

- [SI 단위와 prefix](../references/units-si.md)
- [이상 모델의 적용 범위](../references/ideal-circuit.md)

## 교수자 해설

공통 계산 모듈의 동일 입력 결과로 기준값을 확인합니다. 교수자 ZIP에 실행 가능한 알려진 값이 포함됩니다.

토론할 오류:

- 고정 Vf 근사이며 LED 모델·열 해석은 아닙니다.
- 반올림된 화면 값과 내부 수치의 자릿수를 구분합니다.

확인된 수식 기준값 (물리 검증/실제 시뮬레이션 결과 아님):

```json
{
  "source": "shared_deterministic_calculator",
  "inputs": {
    "supply": 5,
    "forward": 2,
    "current_ma": 10
  },
  "formula": "R = (Vs - Vf) / If",
  "reference_equation": "Ohm law applied to LED current limit",
  "result": {
    "primaryLabel": "Series resistor",
    "primaryValue": 300,
    "primaryUnit": "ohm",
    "explanation": "The resistor drops the remaining supply voltage at the target LED current.",
    "secondary": [
      {
        "label": "Resistor power",
        "value": 0.03,
        "unit": "W"
      }
    ]
  },
  "error": null,
  "scope": "고정 Vf 근사이며 LED 모델·열 해석은 아닙니다.",
  "engine_verification": false
}
```

