# ADC bin과 endpoint

Resistor Edu · adc-code-definitions

코드 수, 이상 bin 폭, endpoint 정의를 구분합니다.

수식: codes=2^N; bin=Vref/2^N; endpoint=Vfs/(2^N−1)

단위: V/code

조건: SAR reference는 bin 정의. 기존 hub는 endpoint 정의.

주의할 해석: 8bit CODE는 측정한 ENOB8이 아닙니다.

다음 실험: 1.2V·8bit의 4.6875mV bin과 endpoint를 따로 적으세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드

[Analog Devices · SAR 구조와 charge redistribution](https://www.analog.com/en/resources/technical-articles/successive-approximation-registers-sar-and-flash-adcs.html) · 외부 링크만 포함
