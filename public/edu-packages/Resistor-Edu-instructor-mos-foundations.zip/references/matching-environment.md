# 주변 환경·방향·dummy

Resistor Edu · matching-environment

같은 W/L 외에 orientation·이웃·배선·온도 조건이 있습니다.

단위: geometry, model ID

조건: 공정 자료·추출·mismatch 모델 필요

주의할 해석: common centroid와 dummy가 항상 최선이라고 가르치지 않습니다.

다음 실험: 기하로 아는 사실과 모델 없이는 모르는 것을 구분하세요.

[ALIGN · 대칭·배치·경계 제약](https://align-analoglayout.github.io/ALIGN-public/notes/const.html) · 외부 링크만 포함 · 독립 ALIGN 엔진 실행 아님

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인
