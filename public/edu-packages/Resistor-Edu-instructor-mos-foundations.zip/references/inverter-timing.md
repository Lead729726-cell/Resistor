# 인버터 timing 기준

Resistor Edu · inverter-timing

정확한 입력/출력 crossing과 부하를 기록합니다.

수식: tpHL=tY,50%,fall−tA,50%,rise

단위: s, ns; Cload: F/fF

조건: matching input event·finite rise·실제 samples

주의할 해석: 50% 지연과 10–90% transition은 다른 수치입니다.

다음 실험: 5fF와 50fF의 actual waveform을 비교하세요.

[연결형 CMOS 실습과 실제 모델 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/edu-inverter-lab.md) · MIT · 실행 증거는 해당 revision에만 유효
