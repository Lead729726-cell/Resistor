# GDS·표시 Z·실제 적층

Resistor Edu · stack-assumptions

XY 마스크와 공정 적층·재료 정보를 구분합니다.

단위: layer/datatype, µm, z scale

조건: 사용한 layer mapping·공정 출처·가상/실제 표기

주의할 해석: 단순 돌출 2.5D를 공정 simulation이라고 부르지 않습니다.

다음 실험: 표시 z scale 변경으로 전기 결과가 바뀌지 않음을 확인하세요.

[KLayout 공식 2.5D 표현](https://www.klayout.de/doc/about/25d_view.html) · 외부 링크만 포함

[KLayout XSection 프로젝트](https://klayoutmatthias.github.io/xsection/) · 외부 링크만 포함 · 현재 Edu에 XSection 실행 연동을 주장하지 않음
