# OP·초기조건·UIC

Resistor Edu · initial-conditions

같은 R/C라도 시작 상태가 다르면 waveform이 달라집니다.

단위: V, A, s

조건: deck의 .ic/UIC·OP 설정과 실제 초기값 확인

주의할 해석: sample waveform으로 미실행 초기조건을 대체하지 않습니다.

다음 실험: 방전 fixture와 pulse falling edge를 비교하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
