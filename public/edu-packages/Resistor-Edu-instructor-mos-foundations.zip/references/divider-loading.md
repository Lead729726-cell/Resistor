# 부하가 있는 분배기

Resistor Edu · divider-loading

아래쪽 branch에 부하가 병렬로 들어갑니다.

수식: Rb=R2||RL; Vout=Vin·Rb/(R1+Rb)

단위: V, Ω

조건: 이상 전압원·선형 저항

주의할 해석: 무부하 식으로 유한 입력 저항을 생략하지 않습니다.

다음 실험: RL=10kΩ와 100kΩ의 실제 OP를 비교하세요.

[Resistor 공통 계산 모듈과 수식 fixture](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/packages/calculators/src/index.ts) · MIT · 이 저장소의 계산 코드

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
