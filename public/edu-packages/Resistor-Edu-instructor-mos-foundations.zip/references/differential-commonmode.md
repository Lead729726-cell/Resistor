# 차동·공통 모드

Resistor Edu · differential-commonmode

같이 움직이는 입력과 서로 벌어지는 입력을 구분합니다.

수식: Vdiff=Vp−Vn; Vcm=(Vp+Vn)/2

단위: V

조건: 입력 범위·bias·외부 구동 명시

주의할 해석: 동일한 geometric placement가 CMRR 수치를 제공하지 않습니다.

다음 실험: Vdiff 고정 후 Vcm 변화 실험을 계획하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
