# D/G/S/B와 body

Resistor Edu · body-bias

MOS의 네 단자와 body 연결을 읽습니다.

단위: V

조건: 공개 모델·전압 정격·body 조건

주의할 해석: GDS 표시 polygon으로 body 접속을 추측하지 않습니다.

다음 실험: schematic B와 LVS extracted body 연결을 비교하세요.

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인
