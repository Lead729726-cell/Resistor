# MOS W/L과 모델

Resistor Edu · mos-model

square-law 직관과 실제 public 모델을 구분합니다.

단위: µm, V, A

조건: 소자 종류·model ID·corner·온도·W/L·nf/m

주의할 해석: W/L만으로 공정·short-channel 전류를 확정하지 않습니다.

다음 실험: 실제 DC sweep에서 model/version을 보존하세요.

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
