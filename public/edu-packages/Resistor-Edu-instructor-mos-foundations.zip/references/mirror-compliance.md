# 전류 미러 compliance

Resistor Edu · mirror-compliance

출력 전압이 전류 전달에 미치는 영향을 봅니다.

수식: 관측 ratio=Iout/Iref

단위: A/A, V

조건: 실제 MOS DC·동일 조건 비교

주의할 해석: 동일 W/L만으로 ratio=1을 보장하지 않습니다.

다음 실험: 두 reference current의 출력 sweep을 비교하세요.

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
