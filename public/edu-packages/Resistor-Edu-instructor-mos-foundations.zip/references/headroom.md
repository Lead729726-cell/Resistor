# headroom·swing·rail

Resistor Edu · headroom

DC bias와 가용 출력 범위를 먼저 확인합니다.

단위: V

조건: 실제 공급·각 MOS 동작점

주의할 해석: 높은 AC gain이 큰 rail-to-rail swing을 보장하지 않습니다.

다음 실험: 게이트 바이어스를 하나 바꾸고 OP를 비교하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용

[공개 SKY130 PDK · 모델·레이어·룰 문서](https://skywater-pdk.readthedocs.io/en/main/) · 외부 링크만 포함 · 각 PDK 파일 라이선스를 별도 확인
