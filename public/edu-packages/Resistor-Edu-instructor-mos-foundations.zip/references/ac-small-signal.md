# AC 소신호 해석

Resistor Edu · ac-small-signal

DC 동작점 주위의 선형 전달을 주파수별로 해석합니다.

수식: H(jω)=Vout/Vin

단위: Hz, V/V, °

조건: 유효 OP·AC source amplitude

주의할 해석: AC plot은 시간 transient waveform이 아닙니다.

다음 실험: DC rail에 가까운 MOS의 OP부터 확인하세요.

[ngspice 공식 문서 · OP/DC/AC/Transient](https://ngspice.sourceforge.io/docs.html) · 외부 링크만 포함 · 문서의 원래 라이선스 적용
