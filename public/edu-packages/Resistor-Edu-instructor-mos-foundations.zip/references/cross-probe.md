# 회로↔mask 연결의 확실성

Resistor Edu · cross-probe

원본 device/net metadata가 있을 때만 대응을 확정합니다.

단위: device ID, net, layer

조건: 원본 annotation·현재 revision·추출 증거

주의할 해석: 이름이 비슷한 polygon만으로 MOS 대응을 확정하지 않습니다.

다음 실험: unknown/candidate/confirmed를 구분해 설명하세요.

[연결형 CMOS 실습과 실제 모델 범위](https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-edu/docs/edu-inverter-lab.md) · MIT · 실행 증거는 해당 revision에만 유효
