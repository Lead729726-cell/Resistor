# Resistor Edu · 차동 쌍 · differential와 common mode

과제 ID: mos-differential-pair · edu-coursepack-20261014-v1 · 수준 2 · 권장 50분

이 문서는 학생용 과제 설명입니다. 학생 제출물이 아니며 실행 결과를 포함하지 않습니다.

## 목표

전류 steering과 입력 범위를 구분합니다.

## 사전 지식

- 전압·전류·단위
- 현재 프로젝트와 revision 확인

## 입력 조건

- VCM=0.9V, Vdiff=10mV, tail bias=0.7V
- TT/27°C · 실제 tail current는 OP에서 읽기

변경 변수: differential_V: 10mV → 20mV

## 수행

1. 새 과제 사본을 만들고 입력·모델·도구 준비 상태를 기록합니다.
2. 회로·포트 또는 기하 구조를 읽고 먼저 변화 방향을 예측합니다.
3. 변경 전 실제 계산/해석/관찰 증거를 저장합니다. 미지원 항목은 이유를 적습니다.
4. differential_V: 10mV → 20mV 이외의 조건을 유지하고 변경 후 증거와 비교합니다.
5. 관찰 → 규칙/모델 → 판단 근거 → 다음 실험 순서로 자신의 설명을 저장합니다.

## 관찰

- OUTP/OUTN·branch current
- tail current와 입력 common mode

## 사전·사후 개념 질문

1. 두 입력을 같이 이동하는 변화와 차동 변화가 같은가요?
2. 대칭 소자에서 실제 offset은 어떻게 측정하나요?

같은 질문에 실험 전 예측과 실험 후 근거를 각각 직접 작성합니다. 자동 정답·점수는 없습니다.

## 제출 증거

- 조건·revision 비교표
- 실제 실행 ID/로그 또는 실행 불가 사유
- 학생이 작성한 해석과 다음 실험

## 평가 기준 · 교수자 수동 검토

- 20점 · 프로젝트·revision·모델·입력 조건을 재현 가능하게 기록
- 30점 · OUTP/OUTN·branch current
- 30점 · 두 입력을 같이 이동하는 변화와 차동 변화가 같은가요?
- 20점 · 한계·오류·다음 실험을 근거와 함께 설명

## 실행·판정 범위

모델 기반 deterministic OP/DC. offset·noise·MC 미실행.

DRC/LVS/PEX/시뮬레이션은 독립입니다. not_run·unavailable·엔진 오류·검사 불합격·현재/이전 revision을 구분합니다. 제조 승인과 교육 효과는 증명되지 않았습니다.

## 기하 참고 그림

해당 과제의 기하 fixture 없음

## 학생 레퍼런스

- [차동·공통 모드](../references/differential-commonmode.md)
- [주변 환경·방향·dummy](../references/matching-environment.md)

