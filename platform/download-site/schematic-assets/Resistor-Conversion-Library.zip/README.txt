Actual SKY130 native conversion examples. Source version 37d2437d1704
Six bounded layouts and three bare-GDS recoveries. Native DRC/LVS/PEX and extraction parser comparison are separate. No foundry signoff.
