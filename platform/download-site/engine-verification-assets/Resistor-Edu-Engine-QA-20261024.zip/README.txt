Resistor Edu · actual SKY130 public-deck QA · 2026-10-24
New QA project only. No foundry signoff. Open inverter.register.zip through project import.
Native manifests, reports and logs retain run IDs and project revisions. Never infer other projects passed.
Source: d0ce59812ed19f2827ef20548dde6a1ce11fc4a0
