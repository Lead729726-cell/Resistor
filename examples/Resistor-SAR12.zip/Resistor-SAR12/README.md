# Resistor Indust · SAR12 research reference

[Guide](docs/sar12.md) · [Convergence and native post-layout results](docs/sar12-convergence.md) · [Editable projects, GDS/OASIS and native results](examples/sar12-lab/README.md)

This is a design archive, not an application installer. Post-layout smoke: three selected inputs passed. Full-range electrical characterization, manufacturing qualification and the full digital-controller mask are not established. Use the latest Resistor Indust source and separately installed public SKY130 tools/models.
