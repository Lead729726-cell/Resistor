# Resistor Indust · SAR12 research reference

[Guide](docs/sar12.md) · [Editable projects, GDS/OASIS and native results](examples/sar12-lab/README.md)

This is a design archive, not an application installer. The post-layout attempt failed convergence; no manufacturing qualification or full digital-controller mask is claimed. Use the latest Resistor Indust source and separately installed public SKY130 tools/models.
