read_liberty ../lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog sar12_mapped.v
link_design sar12_controller
create_clock -name SAR_CLK -period 250 [get_ports clk]
set_clock_uncertainty -setup 0.5 [get_clocks SAR_CLK]
set_clock_uncertainty -hold 0.1 [get_clocks SAR_CLK]
set_input_delay -clock SAR_CLK -max 25 [get_ports {reset start comparator}]
set_input_delay -clock SAR_CLK -min 0.5 [get_ports {reset start comparator}]
set_input_transition 0.1 [get_ports {reset start comparator}]
set_output_delay -clock SAR_CLK -max 25 [all_outputs]
set_output_delay -clock SAR_CLK -min 0.5 [all_outputs]
set_load 0.01 [all_outputs]
check_setup -verbose
report_checks -path_delay max -group_path_count 10 -format full_clock_expanded
report_checks -path_delay min -group_path_count 10 -format full_clock_expanded
report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -max_fanout -violators
report_clock_properties
puts STA_NATIVE_COMPLETE
exit
