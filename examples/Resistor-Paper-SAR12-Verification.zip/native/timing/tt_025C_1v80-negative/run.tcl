read_liberty {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/lib/sky130_fd_sc_hd__tt_025C_1v80.lib}
read_verilog {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/timing/sar12_mapped.v}
link_design sar12_controller
create_clock -name SAR_CLK -period 0.2 [get_ports clk]
set_clock_uncertainty -setup 0.005 [get_clocks SAR_CLK]
set_clock_uncertainty -hold 0.0 [get_clocks SAR_CLK]
set_input_delay -clock SAR_CLK -max 0.02 [get_ports {reset start comparator}]
set_input_delay -clock SAR_CLK -min 0.005 [get_ports {reset start comparator}]
set_input_transition 0.1 [get_ports {reset start comparator}]
set_output_delay -clock SAR_CLK -max 0.02 [get_ports {sample eval busy valid trial* code*}]
set_output_delay -clock SAR_CLK -min 0.005 [get_ports {sample eval busy valid trial* code*}]
set_load 0.01 [get_ports {sample eval busy valid trial* code*}]

puts "SETUP_SANITY [check_setup -verbose]"
report_checks -path_delay max -group_path_count 30 -format full_clock_expanded
report_checks -path_delay min -group_path_count 30 -format full_clock_expanded
report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -max_fanout -violators
report_clock_properties
write_sdc {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/timing/tt_025C_1v80-negative/constraints.sdc}
write_sdf {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/timing/tt_025C_1v80-negative/delay.sdf}
puts STA_NATIVE_COMPLETE
exit
