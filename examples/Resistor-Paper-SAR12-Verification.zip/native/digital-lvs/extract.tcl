crashbackups stop
gds read {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/digital-lvs/input.gds}
load sar12_controller
select top cell
port makeall
extract all
ext2spice lvs
ext2spice scale off
ext2spice format ngspice
ext2spice subcircuit on
ext2spice subcircuit top on
ext2spice hierarchy on
ext2spice -o {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/digital-lvs/layout.spice}
puts LVS_EXTRACTION_COMPLETE
quit -noprompt
