(* blackbox *) module sky130_fd_sc_hd__a21o_1(A1,A2,B1,VGND,VNB,VPB,VPWR,X);
inout A1,A2,B1,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__a21oi_1(A1,A2,B1,VGND,VNB,VPB,VPWR,Y);
inout A1,A2,B1,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__and3_1(A,B,C,VGND,VNB,VPB,VPWR,X);
inout A,B,C,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__and4_1(A,B,C,D,VGND,VNB,VPB,VPWR,X);
inout A,B,C,D,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__buf_2(A,VGND,VNB,VPB,VPWR,X);
inout A,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__buf_4(A,VGND,VNB,VPB,VPWR,X);
inout A,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__buf_6(A,VGND,VNB,VPB,VPWR,X);
inout A,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__clkbuf_4(A,VGND,VNB,VPB,VPWR,X);
inout A,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__clkinv_1(A,VGND,VNB,VPB,VPWR,Y);
inout A,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__clkinv_2(A,VGND,VNB,VPB,VPWR,Y);
inout A,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__dfxtp_1(CLK,D,VGND,VNB,VPB,VPWR,Q);
inout CLK,D,VGND,VNB,VPB,VPWR,Q;
endmodule

(* blackbox *) module sky130_fd_sc_hd__mux2i_1(A0,A1,S,VGND,VNB,VPB,VPWR,Y);
inout A0,A1,S,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nand2_1(A,B,VGND,VNB,VPB,VPWR,Y);
inout A,B,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nand2b_1(A_N,B,VGND,VNB,VPB,VPWR,Y);
inout A_N,B,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nand3_1(A,B,C,VGND,VNB,VPB,VPWR,Y);
inout A,B,C,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nand3b_1(A_N,B,C,VGND,VNB,VPB,VPWR,Y);
inout A_N,B,C,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nand4b_1(A_N,B,C,D,VGND,VNB,VPB,VPWR,Y);
inout A_N,B,C,D,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nand4bb_1(A_N,B_N,C,D,VGND,VNB,VPB,VPWR,Y);
inout A_N,B_N,C,D,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nor2_1(A,B,VGND,VNB,VPB,VPWR,Y);
inout A,B,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nor2b_1(A,B_N,VGND,VNB,VPB,VPWR,Y);
inout A,B_N,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nor3_1(A,B,C,VGND,VNB,VPB,VPWR,Y);
inout A,B,C,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__nor4bb_1(A,B,C_N,D_N,VGND,VNB,VPB,VPWR,Y);
inout A,B,C_N,D_N,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__o2111a_1(A1,A2,B1,C1,D1,VGND,VNB,VPB,VPWR,X);
inout A1,A2,B1,C1,D1,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__o21a_1(A1,A2,B1,VGND,VNB,VPB,VPWR,X);
inout A1,A2,B1,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__o21ai_0(A1,A2,B1,VGND,VNB,VPB,VPWR,Y);
inout A1,A2,B1,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__o21bai_1(A1,A2,B1_N,VGND,VNB,VPB,VPWR,Y);
inout A1,A2,B1_N,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__o311ai_0(A1,A2,A3,B1,C1,VGND,VNB,VPB,VPWR,Y);
inout A1,A2,A3,B1,C1,VGND,VNB,VPB,VPWR,Y;
endmodule

(* blackbox *) module sky130_fd_sc_hd__or2_0(A,B,VGND,VNB,VPB,VPWR,X);
inout A,B,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__or3_1(A,B,C,VGND,VNB,VPB,VPWR,X);
inout A,B,C,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__or3b_1(A,B,C_N,VGND,VNB,VPB,VPWR,X);
inout A,B,C_N,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__or4_1(A,B,C,D,VGND,VNB,VPB,VPWR,X);
inout A,B,C,D,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__or4b_1(A,B,C,D_N,VGND,VNB,VPB,VPWR,X);
inout A,B,C,D_N,VGND,VNB,VPB,VPWR,X;
endmodule

(* blackbox *) module sky130_fd_sc_hd__xor2_1(A,B,VGND,VNB,VPB,VPWR,X);
inout A,B,VGND,VNB,VPB,VPWR,X;
endmodule
