read_db {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/pnr/routed.odb}
write_verilog -include_pwr_gnd -remove_cells {sky130_fd_sc_hd__tapvpwrvgnd_1 sky130_fd_sc_hd__fill_1 sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_4 sky130_fd_sc_hd__fill_8} {/mnt/d/Coldbrew/Resistor/.runtime/paper-signoff/digital-lvs/powered.v}
exit
