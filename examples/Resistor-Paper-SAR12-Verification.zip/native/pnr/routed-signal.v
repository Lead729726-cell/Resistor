module sar12_controller (busy,
    clk,
    comparator,
    eval,
    reset,
    sample,
    start,
    valid,
    code,
    trial);
 output busy;
 input clk;
 input comparator;
 output eval;
 input reset;
 output sample;
 input start;
 output valid;
 output [11:0] code;
 output [11:0] trial;


 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire acquiring;
 wire net1;
 wire net2;
 wire clknet_0_clk;
 wire clknet_2_0__leaf_clk;
 wire clknet_2_1__leaf_clk;
 wire clknet_2_2__leaf_clk;
 wire clknet_2_3__leaf_clk;
 wire net3;
 wire net4;
 wire [3:0] bit_index;

 sky130_fd_sc_hd__or3b_1 _131_ (.A(acquiring),
    .B(eval),
    .C_N(busy),
    .X(_113_));
 sky130_fd_sc_hd__nor2_1 _132_ (.A(start),
    .B(busy),
    .Y(_114_));
 sky130_fd_sc_hd__or2_0 _133_ (.A(start),
    .B(busy),
    .X(_115_));
 sky130_fd_sc_hd__nand2_1 _134_ (.A(eval),
    .B(_114_),
    .Y(_116_));
 sky130_fd_sc_hd__a21oi_1 _135_ (.A1(_113_),
    .A2(_116_),
    .B1(net3),
    .Y(_002_));
 sky130_fd_sc_hd__nand2_1 _136_ (.A(net1),
    .B(_115_),
    .Y(_117_));
 sky130_fd_sc_hd__nor2_1 _137_ (.A(net3),
    .B(_117_),
    .Y(_003_));
 sky130_fd_sc_hd__nand2_1 _138_ (.A(_113_),
    .B(_115_),
    .Y(_118_));
 sky130_fd_sc_hd__nand2_1 _139_ (.A(trial[0]),
    .B(_118_),
    .Y(_119_));
 sky130_fd_sc_hd__o21ai_0 _140_ (.A1(comparator),
    .A2(_107_),
    .B1(trial[0]),
    .Y(_120_));
 sky130_fd_sc_hd__or4b_1 _141_ (.A(bit_index[2]),
    .B(bit_index[1]),
    .C(bit_index[0]),
    .D_N(bit_index[3]),
    .X(_121_));
 sky130_fd_sc_hd__xor2_1 _142_ (.A(bit_index[3]),
    .B(_106_),
    .X(_122_));
 sky130_fd_sc_hd__o21ai_0 _143_ (.A1(bit_index[1]),
    .A2(bit_index[0]),
    .B1(bit_index[2]),
    .Y(_123_));
 sky130_fd_sc_hd__nand2_1 _144_ (.A(_106_),
    .B(_123_),
    .Y(_124_));
 sky130_fd_sc_hd__or4b_1 _145_ (.A(bit_index[3]),
    .B(bit_index[2]),
    .C(bit_index[1]),
    .D_N(bit_index[0]),
    .X(_125_));
 sky130_fd_sc_hd__a21o_1 _146_ (.A1(_120_),
    .A2(_125_),
    .B1(net2),
    .X(_126_));
 sky130_fd_sc_hd__a21oi_1 _147_ (.A1(_119_),
    .A2(_126_),
    .B1(net3),
    .Y(_004_));
 sky130_fd_sc_hd__nand2_1 _148_ (.A(trial[1]),
    .B(_118_),
    .Y(_127_));
 sky130_fd_sc_hd__o21ai_0 _149_ (.A1(comparator),
    .A2(_125_),
    .B1(trial[1]),
    .Y(_128_));
 sky130_fd_sc_hd__or4b_1 _150_ (.A(bit_index[3]),
    .B(bit_index[2]),
    .C(bit_index[0]),
    .D_N(bit_index[1]),
    .X(_129_));
 sky130_fd_sc_hd__a21o_1 _151_ (.A1(_128_),
    .A2(_129_),
    .B1(net2),
    .X(_130_));
 sky130_fd_sc_hd__a21oi_1 _152_ (.A1(_127_),
    .A2(_130_),
    .B1(net3),
    .Y(_005_));
 sky130_fd_sc_hd__nand2_1 _153_ (.A(trial[2]),
    .B(_118_),
    .Y(_033_));
 sky130_fd_sc_hd__o21ai_0 _154_ (.A1(comparator),
    .A2(_129_),
    .B1(trial[2]),
    .Y(_034_));
 sky130_fd_sc_hd__nand4bb_1 _155_ (.A_N(bit_index[3]),
    .B_N(bit_index[2]),
    .C(bit_index[1]),
    .D(bit_index[0]),
    .Y(_035_));
 sky130_fd_sc_hd__a21o_1 _156_ (.A1(_034_),
    .A2(_035_),
    .B1(net2),
    .X(_036_));
 sky130_fd_sc_hd__a21oi_1 _157_ (.A1(_033_),
    .A2(_036_),
    .B1(net3),
    .Y(_006_));
 sky130_fd_sc_hd__nand2_1 _158_ (.A(trial[3]),
    .B(_118_),
    .Y(_037_));
 sky130_fd_sc_hd__o21ai_0 _159_ (.A1(comparator),
    .A2(_035_),
    .B1(trial[3]),
    .Y(_038_));
 sky130_fd_sc_hd__or4b_1 _160_ (.A(bit_index[3]),
    .B(bit_index[1]),
    .C(bit_index[0]),
    .D_N(bit_index[2]),
    .X(_039_));
 sky130_fd_sc_hd__a21o_1 _161_ (.A1(_038_),
    .A2(_039_),
    .B1(net2),
    .X(_040_));
 sky130_fd_sc_hd__a21oi_1 _162_ (.A1(_037_),
    .A2(_040_),
    .B1(net3),
    .Y(_007_));
 sky130_fd_sc_hd__nand2_1 _163_ (.A(trial[4]),
    .B(_118_),
    .Y(_041_));
 sky130_fd_sc_hd__o21ai_0 _164_ (.A1(comparator),
    .A2(_039_),
    .B1(trial[4]),
    .Y(_042_));
 sky130_fd_sc_hd__nand4bb_1 _165_ (.A_N(bit_index[3]),
    .B_N(bit_index[1]),
    .C(bit_index[0]),
    .D(bit_index[2]),
    .Y(_043_));
 sky130_fd_sc_hd__a21o_1 _166_ (.A1(_042_),
    .A2(_043_),
    .B1(net2),
    .X(_044_));
 sky130_fd_sc_hd__a21oi_1 _167_ (.A1(_041_),
    .A2(_044_),
    .B1(net3),
    .Y(_008_));
 sky130_fd_sc_hd__nand2_1 _168_ (.A(trial[5]),
    .B(_118_),
    .Y(_045_));
 sky130_fd_sc_hd__o21ai_0 _169_ (.A1(comparator),
    .A2(_043_),
    .B1(trial[5]),
    .Y(_046_));
 sky130_fd_sc_hd__nand4bb_1 _170_ (.A_N(bit_index[3]),
    .B_N(bit_index[0]),
    .C(bit_index[1]),
    .D(bit_index[2]),
    .Y(_047_));
 sky130_fd_sc_hd__a21o_1 _171_ (.A1(_046_),
    .A2(_047_),
    .B1(net2),
    .X(_048_));
 sky130_fd_sc_hd__a21oi_1 _172_ (.A1(_045_),
    .A2(_048_),
    .B1(net3),
    .Y(_009_));
 sky130_fd_sc_hd__nand2_1 _173_ (.A(trial[6]),
    .B(_118_),
    .Y(_049_));
 sky130_fd_sc_hd__o21ai_0 _174_ (.A1(comparator),
    .A2(_047_),
    .B1(trial[6]),
    .Y(_050_));
 sky130_fd_sc_hd__nand4b_1 _175_ (.A_N(bit_index[3]),
    .B(bit_index[2]),
    .C(bit_index[1]),
    .D(bit_index[0]),
    .Y(_051_));
 sky130_fd_sc_hd__a21o_1 _176_ (.A1(_050_),
    .A2(_051_),
    .B1(net2),
    .X(_052_));
 sky130_fd_sc_hd__a21oi_1 _177_ (.A1(_049_),
    .A2(_052_),
    .B1(net3),
    .Y(_010_));
 sky130_fd_sc_hd__nand2_1 _178_ (.A(trial[7]),
    .B(_118_),
    .Y(_053_));
 sky130_fd_sc_hd__o21ai_0 _179_ (.A1(comparator),
    .A2(_051_),
    .B1(trial[7]),
    .Y(_054_));
 sky130_fd_sc_hd__a21o_1 _180_ (.A1(_121_),
    .A2(_054_),
    .B1(net2),
    .X(_055_));
 sky130_fd_sc_hd__a21oi_1 _181_ (.A1(_053_),
    .A2(_055_),
    .B1(net3),
    .Y(_011_));
 sky130_fd_sc_hd__nand2_1 _182_ (.A(trial[8]),
    .B(_118_),
    .Y(_056_));
 sky130_fd_sc_hd__o21ai_0 _183_ (.A1(comparator),
    .A2(_121_),
    .B1(trial[8]),
    .Y(_057_));
 sky130_fd_sc_hd__nand4bb_1 _184_ (.A_N(bit_index[2]),
    .B_N(bit_index[1]),
    .C(bit_index[0]),
    .D(bit_index[3]),
    .Y(_058_));
 sky130_fd_sc_hd__a21o_1 _185_ (.A1(_057_),
    .A2(_058_),
    .B1(net2),
    .X(_059_));
 sky130_fd_sc_hd__a21oi_1 _186_ (.A1(_056_),
    .A2(_059_),
    .B1(net3),
    .Y(_012_));
 sky130_fd_sc_hd__nand2_1 _187_ (.A(trial[9]),
    .B(_118_),
    .Y(_060_));
 sky130_fd_sc_hd__o21ai_0 _188_ (.A1(comparator),
    .A2(_058_),
    .B1(trial[9]),
    .Y(_061_));
 sky130_fd_sc_hd__nand4bb_1 _189_ (.A_N(bit_index[2]),
    .B_N(bit_index[0]),
    .C(bit_index[1]),
    .D(bit_index[3]),
    .Y(_062_));
 sky130_fd_sc_hd__a21o_1 _190_ (.A1(_061_),
    .A2(_062_),
    .B1(_108_),
    .X(_063_));
 sky130_fd_sc_hd__a21oi_1 _191_ (.A1(_060_),
    .A2(_063_),
    .B1(net3),
    .Y(_013_));
 sky130_fd_sc_hd__nand2_1 _192_ (.A(trial[10]),
    .B(_118_),
    .Y(_064_));
 sky130_fd_sc_hd__o21ai_0 _193_ (.A1(comparator),
    .A2(_062_),
    .B1(trial[10]),
    .Y(_065_));
 sky130_fd_sc_hd__nand4b_1 _194_ (.A_N(bit_index[2]),
    .B(bit_index[1]),
    .C(bit_index[0]),
    .D(bit_index[3]),
    .Y(_066_));
 sky130_fd_sc_hd__a21o_1 _195_ (.A1(_065_),
    .A2(_066_),
    .B1(_108_),
    .X(_067_));
 sky130_fd_sc_hd__a21oi_1 _196_ (.A1(_064_),
    .A2(_067_),
    .B1(net3),
    .Y(_014_));
 sky130_fd_sc_hd__o21a_1 _197_ (.A1(comparator),
    .A2(_066_),
    .B1(trial[11]),
    .X(_068_));
 sky130_fd_sc_hd__nor4bb_1 _198_ (.A(bit_index[1]),
    .B(bit_index[0]),
    .C_N(bit_index[3]),
    .D_N(bit_index[2]),
    .Y(_069_));
 sky130_fd_sc_hd__o311ai_0 _199_ (.A1(acquiring),
    .A2(_068_),
    .A3(_069_),
    .B1(busy),
    .C1(_113_),
    .Y(_070_));
 sky130_fd_sc_hd__nand2_1 _200_ (.A(trial[11]),
    .B(_118_),
    .Y(_071_));
 sky130_fd_sc_hd__a21oi_1 _201_ (.A1(_070_),
    .A2(_071_),
    .B1(net3),
    .Y(_015_));
 sky130_fd_sc_hd__o21ai_0 _202_ (.A1(_107_),
    .A2(net2),
    .B1(code[0]),
    .Y(_072_));
 sky130_fd_sc_hd__o21ai_0 _203_ (.A1(net1),
    .A2(_120_),
    .B1(_072_),
    .Y(_073_));
 sky130_fd_sc_hd__nor2b_1 _204_ (.A(net3),
    .B_N(_073_),
    .Y(_016_));
 sky130_fd_sc_hd__o21ai_0 _205_ (.A1(_107_),
    .A2(net2),
    .B1(code[1]),
    .Y(_074_));
 sky130_fd_sc_hd__o21a_1 _206_ (.A1(net1),
    .A2(_128_),
    .B1(_074_),
    .X(_075_));
 sky130_fd_sc_hd__nor2_1 _207_ (.A(net3),
    .B(_075_),
    .Y(_017_));
 sky130_fd_sc_hd__o21ai_0 _208_ (.A1(_107_),
    .A2(net2),
    .B1(code[2]),
    .Y(_076_));
 sky130_fd_sc_hd__o21a_1 _209_ (.A1(_109_),
    .A2(_034_),
    .B1(_076_),
    .X(_077_));
 sky130_fd_sc_hd__nor2_1 _210_ (.A(net3),
    .B(_077_),
    .Y(_018_));
 sky130_fd_sc_hd__o21ai_0 _211_ (.A1(_107_),
    .A2(net2),
    .B1(code[3]),
    .Y(_078_));
 sky130_fd_sc_hd__o21a_1 _212_ (.A1(_109_),
    .A2(_038_),
    .B1(_078_),
    .X(_079_));
 sky130_fd_sc_hd__nor2_1 _213_ (.A(net3),
    .B(_079_),
    .Y(_019_));
 sky130_fd_sc_hd__nand2_1 _214_ (.A(code[4]),
    .B(_109_),
    .Y(_080_));
 sky130_fd_sc_hd__or2_0 _215_ (.A(_109_),
    .B(_042_),
    .X(_081_));
 sky130_fd_sc_hd__a21oi_1 _216_ (.A1(_080_),
    .A2(_081_),
    .B1(net3),
    .Y(_020_));
 sky130_fd_sc_hd__nand2_1 _217_ (.A(code[5]),
    .B(_109_),
    .Y(_082_));
 sky130_fd_sc_hd__or2_0 _218_ (.A(_109_),
    .B(_046_),
    .X(_083_));
 sky130_fd_sc_hd__a21oi_1 _219_ (.A1(_082_),
    .A2(_083_),
    .B1(net3),
    .Y(_021_));
 sky130_fd_sc_hd__nand2_1 _220_ (.A(code[6]),
    .B(_109_),
    .Y(_084_));
 sky130_fd_sc_hd__or2_0 _221_ (.A(_109_),
    .B(_050_),
    .X(_085_));
 sky130_fd_sc_hd__a21oi_1 _222_ (.A1(_084_),
    .A2(_085_),
    .B1(net3),
    .Y(_022_));
 sky130_fd_sc_hd__nand2_1 _223_ (.A(code[7]),
    .B(net1),
    .Y(_086_));
 sky130_fd_sc_hd__or2_0 _224_ (.A(_109_),
    .B(_054_),
    .X(_087_));
 sky130_fd_sc_hd__a21oi_1 _225_ (.A1(_086_),
    .A2(_087_),
    .B1(net3),
    .Y(_023_));
 sky130_fd_sc_hd__o21ai_0 _226_ (.A1(_107_),
    .A2(net2),
    .B1(code[8]),
    .Y(_088_));
 sky130_fd_sc_hd__o21a_1 _227_ (.A1(net1),
    .A2(_057_),
    .B1(_088_),
    .X(_089_));
 sky130_fd_sc_hd__nor2_1 _228_ (.A(net3),
    .B(_089_),
    .Y(_024_));
 sky130_fd_sc_hd__nand2_1 _229_ (.A(code[9]),
    .B(net1),
    .Y(_090_));
 sky130_fd_sc_hd__or2_0 _230_ (.A(net1),
    .B(_061_),
    .X(_091_));
 sky130_fd_sc_hd__a21oi_1 _231_ (.A1(_090_),
    .A2(_091_),
    .B1(net3),
    .Y(_025_));
 sky130_fd_sc_hd__nand2_1 _232_ (.A(code[10]),
    .B(net1),
    .Y(_092_));
 sky130_fd_sc_hd__or2_0 _233_ (.A(net1),
    .B(_065_),
    .X(_093_));
 sky130_fd_sc_hd__a21oi_1 _234_ (.A1(_092_),
    .A2(_093_),
    .B1(net3),
    .Y(_026_));
 sky130_fd_sc_hd__mux2i_1 _235_ (.A0(_068_),
    .A1(code[11]),
    .S(net1),
    .Y(_094_));
 sky130_fd_sc_hd__nor2_1 _236_ (.A(net3),
    .B(_094_),
    .Y(_027_));
 sky130_fd_sc_hd__nor2_1 _237_ (.A(acquiring),
    .B(net4),
    .Y(_095_));
 sky130_fd_sc_hd__nor3_1 _238_ (.A(busy),
    .B(net3),
    .C(_095_),
    .Y(_028_));
 sky130_fd_sc_hd__o2111a_1 _239_ (.A1(_107_),
    .A2(_108_),
    .B1(_111_),
    .C1(_113_),
    .D1(_115_),
    .X(_096_));
 sky130_fd_sc_hd__nand2_1 _240_ (.A(bit_index[0]),
    .B(busy),
    .Y(_097_));
 sky130_fd_sc_hd__a21oi_1 _241_ (.A1(_096_),
    .A2(_097_),
    .B1(net3),
    .Y(_098_));
 sky130_fd_sc_hd__o21ai_0 _242_ (.A1(_105_),
    .A2(_096_),
    .B1(_098_),
    .Y(_029_));
 sky130_fd_sc_hd__a21oi_1 _243_ (.A1(_096_),
    .A2(_097_),
    .B1(bit_index[1]),
    .Y(_099_));
 sky130_fd_sc_hd__and4_1 _244_ (.A(bit_index[1]),
    .B(_105_),
    .C(busy),
    .D(_096_),
    .X(_100_));
 sky130_fd_sc_hd__o21bai_1 _245_ (.A1(_099_),
    .A2(_100_),
    .B1_N(net3),
    .Y(_030_));
 sky130_fd_sc_hd__nand2b_1 _246_ (.A_N(_096_),
    .B(bit_index[2]),
    .Y(_101_));
 sky130_fd_sc_hd__nand3_1 _247_ (.A(busy),
    .B(_124_),
    .C(_096_),
    .Y(_102_));
 sky130_fd_sc_hd__a21oi_1 _248_ (.A1(_101_),
    .A2(_102_),
    .B1(net3),
    .Y(_031_));
 sky130_fd_sc_hd__and3_1 _249_ (.A(busy),
    .B(_122_),
    .C(_096_),
    .X(_103_));
 sky130_fd_sc_hd__nor2_1 _250_ (.A(bit_index[3]),
    .B(_096_),
    .Y(_104_));
 sky130_fd_sc_hd__o21bai_1 _251_ (.A1(_103_),
    .A2(_104_),
    .B1_N(net3),
    .Y(_032_));
 sky130_fd_sc_hd__clkinv_1 _252_ (.A(bit_index[0]),
    .Y(_105_));
 sky130_fd_sc_hd__or3_1 _253_ (.A(bit_index[2]),
    .B(bit_index[1]),
    .C(bit_index[0]),
    .X(_106_));
 sky130_fd_sc_hd__or4_1 _254_ (.A(bit_index[3]),
    .B(bit_index[2]),
    .C(bit_index[1]),
    .D(bit_index[0]),
    .X(_107_));
 sky130_fd_sc_hd__nand3b_1 _255_ (.A_N(acquiring),
    .B(eval),
    .C(busy),
    .Y(_108_));
 sky130_fd_sc_hd__or2_0 _256_ (.A(_107_),
    .B(_108_),
    .X(_109_));
 sky130_fd_sc_hd__nor2_1 _257_ (.A(net3),
    .B(net1),
    .Y(_000_));
 sky130_fd_sc_hd__nor2b_1 _258_ (.A(busy),
    .B_N(start),
    .Y(_110_));
 sky130_fd_sc_hd__nand2_1 _259_ (.A(acquiring),
    .B(busy),
    .Y(_111_));
 sky130_fd_sc_hd__a21oi_1 _260_ (.A1(sample),
    .A2(_111_),
    .B1(_110_),
    .Y(_112_));
 sky130_fd_sc_hd__nor2_1 _261_ (.A(net3),
    .B(_112_),
    .Y(_001_));
 sky130_fd_sc_hd__dfxtp_1 _262_ (.D(_000_),
    .Q(valid),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _263_ (.D(_001_),
    .Q(sample),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _264_ (.D(_002_),
    .Q(eval),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _265_ (.D(_003_),
    .Q(busy),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _266_ (.D(_004_),
    .Q(trial[0]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _267_ (.D(_005_),
    .Q(trial[1]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _268_ (.D(_006_),
    .Q(trial[2]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _269_ (.D(_007_),
    .Q(trial[3]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _270_ (.D(_008_),
    .Q(trial[4]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _271_ (.D(_009_),
    .Q(trial[5]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _272_ (.D(_010_),
    .Q(trial[6]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _273_ (.D(_011_),
    .Q(trial[7]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _274_ (.D(_012_),
    .Q(trial[8]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _275_ (.D(_013_),
    .Q(trial[9]),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _276_ (.D(_014_),
    .Q(trial[10]),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _277_ (.D(_015_),
    .Q(trial[11]),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _278_ (.D(_016_),
    .Q(code[0]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _279_ (.D(_017_),
    .Q(code[1]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _280_ (.D(_018_),
    .Q(code[2]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _281_ (.D(_019_),
    .Q(code[3]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _282_ (.D(_020_),
    .Q(code[4]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _283_ (.D(_021_),
    .Q(code[5]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _284_ (.D(_022_),
    .Q(code[6]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _285_ (.D(_023_),
    .Q(code[7]),
    .CLK(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _286_ (.D(_024_),
    .Q(code[8]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _287_ (.D(_025_),
    .Q(code[9]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _288_ (.D(_026_),
    .Q(code[10]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _289_ (.D(_027_),
    .Q(code[11]),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _290_ (.D(_028_),
    .Q(acquiring),
    .CLK(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _291_ (.D(_029_),
    .Q(bit_index[0]),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _292_ (.D(_030_),
    .Q(bit_index[1]),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _293_ (.D(_031_),
    .Q(bit_index[2]),
    .CLK(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _294_ (.D(_032_),
    .Q(bit_index[3]),
    .CLK(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_4 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_4 clkbuf_2_0__f_clk (.A(clknet_0_clk),
    .X(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_4 clkbuf_2_1__f_clk (.A(clknet_0_clk),
    .X(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__clkbuf_4 clkbuf_2_2__f_clk (.A(clknet_0_clk),
    .X(clknet_2_2__leaf_clk));
 sky130_fd_sc_hd__clkbuf_4 clkbuf_2_3__f_clk (.A(clknet_0_clk),
    .X(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__clkinv_1 clkload0 (.A(clknet_2_0__leaf_clk));
 sky130_fd_sc_hd__clkinv_1 clkload1 (.A(clknet_2_1__leaf_clk));
 sky130_fd_sc_hd__clkinv_2 clkload2 (.A(clknet_2_3__leaf_clk));
 sky130_fd_sc_hd__buf_2 hold3 (.A(reset),
    .X(net3));
 sky130_fd_sc_hd__buf_2 hold4 (.A(start),
    .X(net4));
 sky130_fd_sc_hd__buf_4 max_cap1 (.A(_109_),
    .X(net1));
 sky130_fd_sc_hd__buf_6 max_cap2 (.A(_108_),
    .X(net2));
endmodule
