# Resistor Indust hardware lab

[Guide](docs/hardware-workbench.md) · [Projects and evidence](examples/hardware-lab/README.md)

Design archive, not an installer. Public tool/PDK installation is separate. No full-chip or manufacturing qualification.
