# Resistor Indust hardware validation

[Guide](docs/hardware-validation.md) · [Editable projects and actual native evidence](examples/hardware-validation/README.md)

This design/evidence ZIP is not an installer. Public tools and PDK installation is separate. No commercial or manufacturing signoff.
