# Resistor Indust · ADC16 projects

16-bit SAR / second-order Sigma-delta / Pipeline; 23 editable circuit blocks
and 3 physical projects. These are research references, not silicon-qualified
16-effective-bit ADCs. No new application installer is included.

Open a `projects/*.register.zip` using Resistor Indust project import.
Use the current source engine. Imports inherit no engine PASS results.

- projects/index.json: editable hierarchy and physical projects
- native/index.json: actual execution summaries, including accuracy FAILs
- physical/index.json: public SKY130 DRC/LVS/extraction runs
- qa/verification.json: actual independent RTL/gate/CMOS replay
- import-exchange.json: GDS roundtrip and import checks
- ARCHIVE-SCOPE.json: individually downloadable original large raw/GDS files

SAR untrimmed maximum error: 19 LSB. Sigma-delta untrimmed maximum DC error:
119 LSB. Pipeline measured 1 LSB at 0.15V DC only. Noise, mismatch, full-input
INL/DNL, complete ADC post-layout accuracy and manufacturing signoff remain
unverified. Offline trim study does not change the RTL or raw verdicts.

Korean guide and reproduction:
https://github.com/Lead729726-cell/Resistor/blob/codex/resistor-indust/docs/adc16-lab.md
